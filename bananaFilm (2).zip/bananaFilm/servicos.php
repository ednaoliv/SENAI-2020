<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Banana Film Latoaria e Pintura</title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="favicon.ico.png"/>
        <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Signika+Negative:wght@700&display=swap" rel="stylesheet">
        
    </head>
    <body>
        <header>
            <div id="logo">
                <img src="imagens/logobanana.png"/>
                <p>Latoaria e Pintura</p>
            </div>
            
            <nav id="menuTopo">
                <a href="index.php">home</a>
                <a href="sobre.php">sobre</a>
                <a href="servicos.php">serviços</a>
                <a href="contato.php">contato</a>
            </nav>
        </header>
        
        <div id="foto">
            <img src="imagens/servicosbanana.jpg">
        </div>
             
        
        <footer>
            <div id="direita">
                <p>Segunda á Sexta: 07:30 - 18:30</p>
                <br>                
                 <a href="https://www.google.com/maps/place/
                   Banana+Film+Mec%C3%A2nica+Latoaria+e+Pintura/@-26.9048912,
                   -49.0989927,17z/data=!3m1!4b1!4m5!3m4!1s0x94df1ec8ccc000bf:
                    0xbb66fc8a5cbbfa31!8m2!3d-26.9048912!4d-49.096804">
                    Rua Benjamin Constant, 2239 <br>
                    Asilo, Blumenau - SC, 89035-100
                </a>               
            </div>              
           
            <div id="esquerda">
                <a href="contato.php">
                 Faça um orçamento!      
                </a>               
                <br>
                <br>
                <p>(47) 9905-7691 | Edson</p>                
                <p>(47) 3327-4247</p>
                <p>e-mail: edban10@gmail.com</p>
            </div>
        </footer>
    </body>
</html>
