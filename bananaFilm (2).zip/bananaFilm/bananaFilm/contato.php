<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="favicon.ico.png"/>
        
        
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
