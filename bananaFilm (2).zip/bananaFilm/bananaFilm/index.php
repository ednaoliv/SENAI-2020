<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Banana Film Latoaria e Pintura</title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="favicon.ico.png"/>
        <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Signika+Negative:wght@700&display=swap" rel="stylesheet">
        
    </head>
    <body>
        <header>
            <div id="logo">
                <img src="imagens/logobanana.png"/>
                <p>Latoaria e Pintura</p>
            </div>
            
            <nav id="menuTopo">
                <a href="index.php">home</a>
                <a href="sobre.php">sobre</a>
                <a href="servicos.php">serviços</a>
                <a href="contato.php">contato</a>
            </nav>
        </header>
        
        <div id="meiosite">
            <img src="imagens/bannersite.jpg"/>
        </div>
        
        <footer>
            <div id="horario">
                <p>Segunda á Sexta: 07:30 - 18:30</p>                                
            </div>
            <div id="endereco">
                <p>Rua Benjamin Constant, 2239</p>
                <p>Asilo, Blumenau - SC, 89035-190</p>
            </div>
        </footer>
        
        
        
       
    </body>
</html>
